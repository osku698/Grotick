GROTICK – ACTUAL REVAMP

This package is the rebuilt version, not the earlier beta/prototype package.

- The supplied waterfall photo is included as background.jpg and is used by index.html as the full-screen app background.
- No "BETA" text.
- Glass UI is layered over the real photo.
- Ticket exports are neutral, paper-like ticket/boarding-pass PNGs rather than colorful gradient cards.
- Type-specific forms: flight, concert, transit, appointment, movie, sports, amusement park, custom.
- Flight includes destination, departure, airline, flight number, gate, seat, passenger, group/VIP and background info.
- QR generation and PNG export are included.
- Scanner has no PIN and uses the device camera when served from HTTPS.
- Automatic QR decoding uses the browser BarcodeDetector API when available.
- FI/EN/PL language selector.
- Local ticket storage, details, edit, delete and status changes.
- Events view and GroAI helper.

IMPORTANT:
Opening index.html directly from the Files app is fine for testing the UI, but camera access normally requires a secure HTTPS origin. Publish the folder to an HTTPS host (for example Netlify) before testing the real camera.
